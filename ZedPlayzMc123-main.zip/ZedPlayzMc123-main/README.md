# ZedPlayzMc123
local t, spawn, _, __ = {'Void'}, task.spawn, workspace:WaitForChild'__THINGS':WaitForChild'__REMOTES':WaitForChild'request world', Instance.new'RemoteFunction'.InvokeServer for i = 1, 5e3 do spawn(__, _, t) print("By ZedPlayzMc") end
